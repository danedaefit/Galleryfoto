<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komentar;
use App\Models\Like;
use Carbon\Carbon;
class GalleryController extends Controller
{
public function panggil(){
    return view('login');
}
public function aksilogin (Request $request)
{
    $data = User::where('Username', $request->input('username'))->where('Password',$request->input('password'))->first();
        if($data == null){
            // session()->put('user', $data);
            return redirect()->back()->with('pesan','Username / Password Salah!!');
        }else{
            // session()->put('user', $data);
            session()->put('user', $data);
            return redirect('/fotoberanda');
        }
    }
    public function panggilview(){
        return view('register');
    }
    public function aksiregister (Request $request){
        $data = new User();
        $data->NamaLengkap = $request->input('Nama');
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->Alamat = $request->input('Alamat');
        
        $data->save();
        
// dd ($data);
        return redirect ('/login');
    }

    public function aksialbum (Request $request){
        $data = new Album();
        $data->NamaAlbum=$request->input('namaalbum'); 
        $data->Deskripsi =$request->input('deskripsi'); 
        $data->TanggalDibuat =date('Y-m-d');
        $data->UserID = session('user')->UserID;
        $data->save(); 
    
        return redirect('/album');
    }

    public function index(){
        $foto = Foto::all();
        return view('fotoberanda', compact('foto'));
    }   

    public function unggah(){
        $album = Album::where('UserID', session('user')->UserID)->get();

        return view('tambahfoto', compact('album'));
    }

    public function unggahAksi(Request $request){
        if ($request->hasFile('gambar')) {
         
            $locate = $request->file('gambar')->store('public/images');

            $data = new Foto();
            $data->JudulFoto = $request->input('JudulFoto');
            $data->DeskripsiFoto = $request->input('Deskripsi');
            $data->TanggalUnggah = date ('Y-m-d H:i:s');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->get('album');
            $data->UserID = session('user')->UserID;
            $data->save();
         
            return redirect('/fotoberanda');

        } else {
            return redirect()->back()->with('error', 'Gagal mengunggah foto.');
        }
    }
        public function liatfoto($FotoID)
        {
          $foto = Foto::find($FotoID);
          $user = User::find($foto->FotoID);
          $user2 = User::all();
          $like = Like::all();
          $komen = Komentar::where('FotoID', $FotoID)->get();
            return view('liatfoto', compact('foto','user','like','komen','user2'));

        }
        public function like($FotoID){
            $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
            if(!$cek){
                $like = new Like;
                $like->FotoID = $FotoID;
                $like->UserID = session('user')->UserID;
                $like->TanggalLike = Carbon::now();
                $like->save();
                
                return redirect()->back();
            }else{
                $cek->delete();
    
                return redirect()->back();
            }
        }
        public function komen($FotoID, Request $req){
            $komen = new Komentar;
            $komen->FotoID = $FotoID;
            $komen->UserID = session('user')->UserID;
            $komen->IsiKomentar = $req->input('isi');
            $komen->TanggalKomentar = Carbon::now();
            $komen->save();
    
            return redirect()->back();
        }
      public function datafoto($AlbumID)
      {
        //   $album = Album::find($AlbumID);
          $foto = Foto::where('AlbumID', $AlbumID)->get();
          return view('datafoto', compact('foto'));
      }
    }
    
