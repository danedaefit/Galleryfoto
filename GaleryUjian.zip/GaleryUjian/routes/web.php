<?php

use App\Http\Controllers\GalleryController;
use Illuminate\Support\Facades\Route;
use App\Models\Album;
use App\Models\Foto;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/fotoberanda', [GalleryController::class, 'index']);

Route::get('/login', [GalleryController::class,'panggil']);
Route::post('/fotoberanda', [GalleryController::class,'aksilogin']);
// Route::post('/login/store', [GalleryController::class,'store']);

Route::get('/register', [GalleryController::class,'panggilview']);
// Route::post('/register', [GalleryController::class,'aksiregister']);
Route::post('/login', [GalleryController::class,'aksiregister']);
Route::post('/album', [GalleryController::class,'aksialbum']);

Route::get('/tambahfoto', [GalleryController::class, 'unggah']);
Route::post('/tambahfoto', [GalleryController::class, 'unggahAksi']);

Route::get('/home', function () {
    return view('home');
});
Route::get('/album', function () {
    $bebas = album::all();
    return view('album', compact('bebas'));
});
Route::get('/beranda', function () {
    $foto = Foto::all();
    return view('Foto', compact('foto'));
});
Route::get('/fotoberanda', function () {
    $foto = Foto::all();
    return view('fotoberanda', compact('foto'));
});
Route::get('/addalbum', function () {
    return view('addalbum');
});
// Route::get('/liatfoto', function ($AlbumID) {
//     return view('liatfoto', compact('foto'));
// });


Route::get('/datafoto{AlbumID}', [GalleryController::class, 'datafoto']);

Route::get('/liatfoto{FotoID}', [GalleryController::class, 'liatfoto']);
Route::get('/berilike/{FotoID}', [GalleryController::class, 'like']);
Route::post('/berikomen/{FotoID}', [GalleryController::class, 'komen']);

