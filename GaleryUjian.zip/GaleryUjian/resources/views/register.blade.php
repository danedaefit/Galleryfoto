<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .garisatas{
            background-color:  #BC8741;
            height: 5px;
            margin: 3% 6%;
        }
        .textregister{
            text-align: center;
            color: white;
            font-size: 50px;
            text-shadow: 0 0 12px #222;
        }
        input[type="text"],input[type="password"], input[type="email"]{
            width: 400px;
            height: 50px;
            border-radius: 20px;
            border: none;
            margin: 10px 1px;
        }
        input[type="submit"]{
            width: 150px;
            height: 50px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            background-color: #BC8741;
            color: #ffffff;
            font-size: 20px;
            text-shadow: 0 0 12px #222;
        }
    </style>
</head>
<body>
    <h1 class="textregister"> Registrasi</h1>
    <center>
        <form action="/login" method="post">
        @csrf
    <table>
        <tr>
            <td><input type="text" name="Nama" placeholder="Masukan Nama Lengkap"></td>
        </tr>
        <tr>
            <td><input type="text" name="Username" placeholder="Masukan Username"></td>
        </tr>
        <tr>
            <td><input type="text" name="Password" placeholder="Tambahkan Password"></td>
        </tr>
        <tr>
            <td><input type="text" name="Email" placeholder="Masukan Email"></td>
        </tr>
        <tr>
            <td><input type="text" name="Alamat" placeholder="Tambahkan Alamat"></td>
        </tr>
        <tr>
            <td>
            <center> <input type="submit" value="Sign Up"></center>
            </td>
        </tr>
    </table>
</form>
</center>
</body>
</html>