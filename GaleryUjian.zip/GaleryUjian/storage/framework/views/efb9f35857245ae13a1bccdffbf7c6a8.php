<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
    <style>
       body {
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .container {
            width: 1200px;
            margin: 20px auto;
            columns: 4;
            column-gap: 20px;
            margin-top: 100px;


        }
        .container .photo {
            width: 100%;
            margin-bottom: 10px;
            break-inside: avoid;
        }

        .container .photo img {
            max-width: 100%;
            border-radius: 10px;
        }

        @media (max-width: 1200px) {
            .container {
                width: calc(100% - 40px);
                columns: 3;
            }
        }

        @media (max-width: 768px) {
            .container {
                columns: 2;
            }
        }

        @media (max-width: 480px) {
            .container {
                columns: 1;
            }
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6% 6% 6%;
            margin-bottom: -50px;
        }
        .keluar{
            position: absolute;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 5%;

        }
        .keluar p a{
            color: #BC8741;
            text-decoration: none;
        }
        .masuk{
            position: absolute;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 12%;

        }
        .masuk p a{
            color: #BC8741;
            text-decoration: none;
        }
        .back h1 a{
            color: #BC8741;
            text-decoration: none;
        }
        .back{
            position: absolute;
            z-index: 9999;
            transform: translate(-25%, -50%);
            top: 3%;
            left: 8%;
        }
        
    </style>

</head>

<body>
    <hr class="garisatas">
    <div class="back">
       
        <h1><p><a href="album"><</a></p></h1>
       
      </div>
    <div class="keluar">
      <p><a href="/home"> LOGOUT</a></p>
    </div>
    <div class="masuk">
      <p><a href="/album"> MY ALBUM</a></p>
    </div>
  
    <div class="container">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="photo"><a href="/liatfoto<?php echo e($Fotos->FotoID); ?>"><img src="<?php echo e(Storage::url($Fotos->LokasiFile)); ?>" alt=""></a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\GaleryUjian\resources\views/datafoto.blade.php ENDPATH**/ ?>