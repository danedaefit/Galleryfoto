<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6%;
        }
        .textlogin{
            text-align: center;
            color: #f5f0f0;
            font-size: 50px;
            text-shadow: 0 0 12px #222;
        }
        .garisbawah{
            background-color: #BC8741;
            height: 3px;
            margin: 4% 9%;
            box-shadow: 0px 3px 12px #222;
            border: none;
        }
        input[type="text"],input[type="password"]{
            width: 400px;
            height: 60px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            color: #222

        }
        input[type="submit"]{
            width: 150px;
            height: 50px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            background-color: #BC8741;
            color: #FFFFFF;
            font-size: 20px;
            text-shadow: 0 0 12px #222;
            color: #222;
        }
        .back{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            left: 8%;

        }
        .back h1 a{
            color: #BC8741;
            text-decoration: none;
        }
        .masuk{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            bottom: 7%;
            right: 29%;

        }
        .masuk p a{
            color: #BC8741;
            text-decoration: none;
        }
    </style>
    
</head>
<body>
    <hr class="garisatas">
    <h1 class="textlogin">LOGIN</h1>
    <hr class="garisbawah">
    <center>
        <p><?php echo e(session()->get('pesan') ?? ''); ?></p>
        <form action="/fotoberanda" method="post">
            <?php echo csrf_field(); ?>
        <table>
            <tr>
            <td><input type="text" name="username" id="" placeholder=" Username"></td>
            </tr>
            <tr>
                <td>
                <input type="password" name="password" id="" placeholder=" Password">
                </td>
            </tr>
            <tr>
                <td>
                <center> <input type="submit" value="LOGIN"> </center>
                </td>
            </tr>
        </table>
        <div class="back">
            <h1><a href="/home"><</a></h1>
        </div>
        <div class="masuk">
            <p>doesn't Have Account?<a href="/register">  SIGN UP</a></p>
        </div>
    </form>
    </center>
</body>
</html><?php /**PATH C:\xampp\htdocs\GaleryUjian\resources\views/login.blade.php ENDPATH**/ ?>