<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6% 6% 6%;
        }
        .textlogin{
            text-align: center;
            color: #FFFFFF;
            font-size: 50px;
            text-shadow: 0 0 12px #222;
        }
        .garisbawah{
            background-color: #BC8741;
            height: 3px;
            margin: 6% 9%;
            box-shadow: 0px 3px 12px #222;
            border: none;
        }
        input[type="text"],input[type="password"]{
            width: 400px;
            height: 60px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            color: #222

        }
        input[type="submit"]{
            width: 150px;
            height: 50px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            background-color: #BC8741;
            color: #FFFFFF;
            font-size: 20px;
            text-shadow: 0 0 12px #222;
            color: #222;
        }
        button{
            width: 150px;
            height: 50px;
            border-radius: 20px;
            border: none;
            margin: 20px 1px;
            background-color: #BC8741;
            color: #FFFFFF;
            font-size: 20px;
            text-shadow: 0 0 12px #222;
            color: #222;
        }
        a {
            text-decoration: none;  
            color: white;
        }
    </style>
    
</head>
<body>
   
    <hr class="garisatas">
    <h1 class="textlogin">MAKE YOUR</h1>
    <h1 class="textlogin">MEMORY</h1>
    <h1 class="textlogin">HERE</h1>
    <hr class="garisbawah">
    <center>
    <form action=" ">
        <table>
            <tr>
                <td>
                <center> <button><a href="/login">GET STARTED</a></button></center>
                </td>
            </tr>
        </table>
    </form>
    </center>
</body>
</html><?php /**PATH C:\xampp\htdocs\GaleryUjian\resources\views/home.blade.php ENDPATH**/ ?>