<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
    <style>
        body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6% 6% 6%;
            margin-bottom: -50px;
        }
        .back h1 a{
            color: #BC8741;
            text-decoration: none;
        }
        .keluar{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 4%;
            right: 5%;

        }
        .keluar p a{
            color: #BC8741;
            text-decoration: none;
        }
        .masuk{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 4%;
            right: 11%;

        }
        .masuk p a {
            color: #BC8741;
            text-decoration: none;
        }

    </style>
</head>
<body>
    
    <?php echo $__env->make('fotoberanda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\GaleryUjian\resources\views/beranda.blade.php ENDPATH**/ ?>