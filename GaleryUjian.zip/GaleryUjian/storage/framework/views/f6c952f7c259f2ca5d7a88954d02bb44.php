<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>album</title>

    <style>
        body{
            background-image: url('img/bbb.jpg');
            background-size: cover;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: <weight>;
            font-style: normal;
        }
        
       
        .grid{
             display: grid;
             grid-template-columns: repeat(4, 1fr);
             margin: 0px;
             align-items: center;
             grid-gap: 30px;
        }

        img{
            object-fit: cover;
        }

        .grid > article{
            box-shadow: 10px 5px 5px 0px black;
            border-radius: 20px;
            text-align: center;
            background: rgb(214, 210, 206);
            width: 250px;
            transition: transform;
            margin-top: 150px;
            margin-left: 50px;
        }

        .grid  article img{
            border-top-left-radius: 20px;
            border-top-right-radius: 20px; width: 100%;
        }
       
        .grid > article:hover{
            transform: scale(1.1);
            transition: .3s;
        }

        @media (max-width:1000px){
            .grid{
                grid-template-columns: repeat(2,1fr);
            }
        }

        @media (max-width:1000px){
            .grid{
                grid-template-columns: repeat(1,1fr);
            }
        }
        .garisatas{
            background-color: #BC8741;
            height: 3px;
            margin: 3% 6% 6% 6%;
            margin-bottom: -50px;
            position: fixed;
        }

        .keluar{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 5%;
           

        }
        .keluar  a{
            color: #BC8741;
            text-decoration: none;
            
        }
        .back h1 a{
            color: #BC8741;
            text-decoration: none;
        }
        .back{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            left: 8%;
        }
        .masuk{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 12%;

        }
        .masuk  a{
            color: #BC8741;
            text-decoration: none;
        }
        .come{
            position: fixed;
            z-index: 9999;
            transform: translate(-50%, -50%);
            top: 3%;
            right: 22%;

        }
        .come  a{
            color: #BC8741;
            text-decoration: none;
        }

    </style>
</head>
<body>
    <hr class="garisatas">
    
    <div class="back">       
        <h1><a href="fotoberanda"><</a></h1>       
    </div>   
    <div class="keluar">
      <a href="/home"> LOGOUT</a>
    </div>
    <div class="masuk">
      <a href="/tambahfoto"> ADD PHOTO</a>
    </div>
    <div class="come">
      <a href="/addalbum"> ADD ALBUM</a>
    </div>
  
    <?php $__currentLoopData = $bebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session()->get('user')->UserID == $item->UserID): ?>
    <div class = "container">
        <main class = "grid">
            <article>
                <img src ="img/file.jpg" width="300px" height="300px">
                <a href="/datafoto<?php echo e($item->AlbumID); ?>" style="text-decoration:none; color:#BC8741;">
                <div class = "konten">
                    <h2><?php echo e($item->NamaAlbum); ?></h2>
                    <p><?php echo e($item->TanggalDibuat); ?></p>
                </div>
            </article>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\GaleryUjian\resources\views/album.blade.php ENDPATH**/ ?>